### All Changes

- Updated the _SonarQube_ image to [v9.9.0](https://www.sonarqube.org/sonarqube-9-9/) ([GH release](https://github.com/SonarSource/sonarqube/releases/tag/9.9.0.65466)).
